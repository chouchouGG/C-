#include "primer/p0_trie.h"

// This is a placeholder file for clang-tidy check.
//
// With this file, we can fire run_clang_tidy.py to check `p0_trie.h`,
// as it will filter out all header files and won't check header-only code.
//
// This file is not part of the submission. All of the modifications should
// be done in `src/include/primer/p0_trie.h`.
